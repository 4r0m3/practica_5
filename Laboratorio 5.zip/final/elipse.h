#ifndef ELIPSE_H
#define ELIPSE_H

#include <QGraphicsEllipseItem>
#include <QBrush>

class Elipse : public QGraphicsEllipseItem {
public:
    Elipse(qreal x, qreal y, qreal width, qreal height, const QBrush& brush);
};

#endif // ELIPSE_H
