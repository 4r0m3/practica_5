#include "ventana.h"
#include "./ui_ventana.h"
#include <QKeyEvent>
#include <QTimer>
#include <QDebug>
#include <cstdlib> // Para rand() y srand()
#include <ctime>   // Para time()



ventana::ventana(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ventana)
    , move_x(0)
    , move_y(0)
    , coorX(47)
    , coorY(36)
    , ancho(29)
    , alto(29)
    , coorX1(47)
    , coorY1(36)
    , coorX2(247)
    , coorY2(36)
    , boca_abierta(true)
    ,life(3)
    ,puntaje(0)
    ,cant_elipses(0)
    ,poderActivo(false)
{
    ui->setupUi(this);


    inicailizarEscenario();
    inicializarPersonje();
    inicializarEnemigos();
    InicializarParedes();
    inicializarElipses();
    inicializarPosiciones();
    inicializarPuntosdePoder();


    poderTimer = new QTimer(this);
    connect(poderTimer, &QTimer::timeout, this, &ventana::desactivarPoder);
}



ventana::~ventana()
{
    delete ui;
}

void ventana::inicailizarEscenario(){
    // Inicialización de la escena y fondo
    escena = new QGraphicsScene(this);
    QImage im(PATH_IMG);
    QBrush brush(im);
    escena->addRect(0, 0, 778, 485, QPen(Qt::NoPen), brush);



    ui->graphicsView->setScene(escena);
    ui->graphicsView->show();

    // Inicializar el temporizador
    timerPersonaje = new QTimer(this);
    connect(timerPersonaje, &QTimer::timeout, this, &ventana::actualizar);
    timerPersonaje->start(15);

    // Inicializar temporizador para mover enemigos
    timerEnemigos = new QTimer(this);
    connect(timerEnemigos, &QTimer::timeout, this, &ventana::moverEnemigos);
    timerEnemigos->start(14);

    // Inicializar generador de números aleatorios
    srand(static_cast<unsigned int>(time(nullptr)));
}
void ventana::inicializarPersonje(){
    // Inicialización del personaje Pac-Man
    pixmap = new QPixmap(":/imagens/personaje-removebg-preview.png");
    pacman = new QGraphicsPixmapItem(pixmap->copy(coorX, coorY, ancho, alto));
    pacman->setPos(369, 433); // Posición inicial
    pacman->setScale(0.85);
    escena->addItem(pacman);

    // Inicializar texto para mostrar el puntaje
    textoPuntaje = escena->addText(QString("Puntaje: %1").arg(puntaje));
    textoPuntaje->setPos(650,490); // Posición del texto del puntaje

    //vidas
    vida = new QGraphicsPixmapItem(pixmap->copy(195, 145, 90, 30));
    vida->setPos(10,490);
    vida->setScale(0.85);
    escena->addItem(vida);
}

void ventana::inicializarEnemigos(){
    // Inicializar enemigos
    QPixmap* pixmapEnemigo = new QPixmap(":/imagens/personaje-removebg-preview.png");
    QPixmap texturaNormal1 = pixmapEnemigo->copy(372, 37, 29, 29);
    QPixmap texturaNormal2 = pixmapEnemigo->copy(301, 37, 29, 29);
    QPixmap texturaNormal3 = pixmapEnemigo->copy(301, 104, 29, 29);
    QPixmap texturaNormal4 = pixmapEnemigo->copy(372, 104, 29, 29);
    QPixmap texturaAsustado =pixmapEnemigo->copy(445,39, 29,29);

    QGraphicsPixmapItem* itemEnemigo1 = new QGraphicsPixmapItem(texturaNormal1); //AZUL
    itemEnemigo1->setPos(375, 196);
    itemEnemigo1->setZValue(2);
    escena->addItem(itemEnemigo1);
    enemigos.push_back({itemEnemigo1, -1, 0, SEMIALEATORIO, texturaNormal1, texturaAsustado});  // Movimiento de 1 píxel

    QGraphicsPixmapItem* itemEnemigo2 = new QGraphicsPixmapItem(texturaNormal2); //rojo
    itemEnemigo2->setPos(375, 196);
    itemEnemigo2->setZValue(2);
    escena->addItem(itemEnemigo2);
    enemigos.push_back({itemEnemigo2, 1, 0, SEMIALEATORIO, texturaNormal2, texturaAsustado});  // Movimiento buscando a Pac-Man

    QGraphicsPixmapItem* itemEnemigo4 = new QGraphicsPixmapItem(texturaNormal3); //rosa
    itemEnemigo4->setPos(375, 196);
    itemEnemigo4->setZValue(2);
    escena->addItem(itemEnemigo4);
    enemigos.push_back({itemEnemigo4, 0, -1, SEMIALEATORIO, texturaNormal3, texturaAsustado});  // Movimiento de 1 píxel

    QGraphicsPixmapItem* itemEnemigo3 = new QGraphicsPixmapItem(texturaNormal4);//naranjaw
    itemEnemigo3->setPos(375, 196);
    itemEnemigo3->setZValue(2);
    escena->addItem(itemEnemigo3);
    enemigos.push_back({itemEnemigo3, 0, -1, SEMIALEATORIO, texturaNormal4, texturaAsustado});  // Movimiento de 1 píxel
}

void ventana::keyPressEvent(QKeyEvent *event) {
    switch (event->key()) {
    case Qt::Key_W:
        move_x = 0;
        move_y = -1;
        coorX1 = 147;
        coorY1 = 145;
        break;
    case Qt::Key_S:
        move_x = 0;
        move_y = 1;
        coorX1 = 147;
        coorY1 = 36;
        break;
    case Qt::Key_A:
        move_x = -1;
        move_y = 0;
        coorX1 = 47;
        coorY1 = 145;
        break;
    case Qt::Key_D:
        move_x = 1;
        move_y = 0;
        coorX1 = 47;
        coorY1 = 36;
        break;
    case Qt::Key_P:
        if(timerPersonaje->isActive() && timerEnemigos->isActive()){
            timerPersonaje->stop();
            timerEnemigos->stop();
        }else{
            timerPersonaje->start();
            timerEnemigos->start();
        }
        break;
    case Qt::Key_R:
        if(life == 0){
            inicailizarEscenario();
            inicializarElipses();
            inicializarEnemigos();
            inicializarPersonje();
            inicializarPosiciones();
            InicializarParedes();
            inicializarPuntosdePoder();
            puntaje = 0;
            life = 3;
            move_x = 0;
            move_y = 0;
        }
        else{
            break;
        }
    default:
        QMainWindow::keyPressEvent(event);
        break;
    }
}

const QPoint tunnelEntry(0, 195);  // Coordenadas de entrada del túnel
const QPoint tunnelExit(765, 195);  // Coordenadas de salida del túnel
const int tunnelRadius = 10;  // Radio del área de colisión del túnel

void ventana::actualizar() {
    // Actualizar la posición de Pac-Man
    QPointF newPos = pacman->pos() + QPointF(move_x, move_y);
    pacman->setPos(newPos);

    // Verificar colisiones con las paredes del mapa
    QList<QGraphicsItem*> collidingItems = pacman->collidingItems();
    bool hayColision = false;

    // Iterar sobre los objetos con los que colisiona Pac-Man
    for (QGraphicsItem* item : collidingItems) {
        // Si colisiona con una pared, se establece hayColision en true
        if (std::find(paredes.begin(), paredes.end(), item) != paredes.end()) {
            hayColision = true;
            break;
        }
    }

    // Si hay colisión, revertir el movimiento de Pac-Man
    if (hayColision) {
        pacman->moveBy(-move_x, -move_y);
        move_x = 0;
        move_y = 0;
    } else {
        // Alternar entre las imágenes de Pac-Man con la boca abierta y cerrada
        if (boca_abierta) {
            pacman->setPixmap(pixmap->copy(coorX1, coorY1, ancho, alto));
        } else {
            pacman->setPixmap(pixmap->copy(coorX2, coorY2, ancho, alto));
        }
        boca_abierta = !boca_abierta;
    }

    // Verificar colisiones con las elipses (puntos)
    std::vector<QGraphicsEllipseItem*> elipsesAEliminar;
    for (auto& elipse : elipses) {
        if (pacman->collidesWithItem(elipse)) {
            elipsesAEliminar.push_back(elipse); // Añadir la elipse a la lista de eliminación
            puntaje += 10; // Incrementar el puntaje
            textoPuntaje->setPlainText(QString("Puntaje: %1").arg(puntaje)); // Actualizar el texto del puntaje
        }
    }

    // Actualizar la visualización de vidas según la cantidad de vidas restantes
    if (life == 2) {
        vida = new QGraphicsPixmapItem(pixmap->copy(195, 175, 90, 30));
        vida->setPos(10, 490);
        vida->setScale(0.9);
        escena->addItem(vida);
    } else if (life == 1) {
        vida = new QGraphicsPixmapItem(pixmap->copy(195, 205, 90, 30));
        vida->setPos(10, 490);
        vida->setScale(0.9);
        escena->addItem(vida);
    }

    // Verificar si todos los puntos han sido consumidos
    if (elipses.empty()) {
        ganar();
    }

    // Eliminar los puntos consumidos después de la iteración
    for (auto& elipse : elipsesAEliminar) {
        escena->removeItem(elipse);
        elipses.erase(std::remove(elipses.begin(), elipses.end(), elipse), elipses.end());
        delete elipse;
    }

    // Verificar colisiones con los enemigos
    std::vector<Enemigo*> enemigosAReiniciar;
    for (auto& enemigo : enemigos) {
        QList<QGraphicsItem*> collidingItemsEnemigo = enemigo.item->collidingItems();
        for (QGraphicsItem* item : collidingItemsEnemigo) {
            if (item == pacman) {
                if (poderActivo) {
                    // Eliminar el enemigo de la escena si Pac-Man está en modo poder
                    escena->removeItem(enemigo.item);
                    enemigosAReiniciar.push_back(&enemigo);
                    puntaje += 150;  // Incrementar el puntaje por comer al enemigo
                    textoPuntaje->setPlainText(QString("Puntaje: %1").arg(puntaje));
                    qDebug() << "Enemigo comido por Pac-Man";
                } else {
                    // Reducir vidas si Pac-Man colisiona con un enemigo no asustado
                    life--;
                    qDebug() << "Vidas restantes:" << life;
                    if (life <= 0) {
                        FindelJuego(); // Terminar el juego si no hay más vidas
                    } else {
                        inicializarPosiciones(); // Reiniciar posiciones si aún hay vidas
                    }
                    return;
                }
            }
        }

        // Verificar colisiones de los enemigos con el túnel de entrada y salida
        if (enemigo.item->pos().x() >= tunnelEntry.x() - tunnelRadius && enemigo.item->pos().x() <= tunnelEntry.x() + tunnelRadius &&
            enemigo.item->pos().y() >= tunnelEntry.y() - tunnelRadius && enemigo.item->pos().y() <= tunnelEntry.y() + tunnelRadius) {
            enemigo.item->setPos(tunnelExit.x() - tunnelRadius - 1, tunnelExit.y());
            qDebug() << "Enemigo ha sido teletransportado a la salida del túnel";
        }

        if (enemigo.item->pos().x() >= tunnelExit.x() - tunnelRadius && enemigo.item->pos().x() <= tunnelExit.x() + tunnelRadius &&
            enemigo.item->pos().y() >= tunnelExit.y() - tunnelRadius && enemigo.item->pos().y() <= tunnelExit.y() + tunnelRadius) {
            enemigo.item->setPos(tunnelEntry.x() + tunnelRadius + 1, tunnelEntry.y());
            qDebug() << "Enemigo ha sido teletransportado a la entrada del túnel";
        }
    }

    // Reiniciar enemigos comidos a su estado normal y posición original
    for (auto& enemigo : enemigosAReiniciar) {
        enemigo->item->setPixmap(enemigo->texturaNormal);
        enemigo->item->setPos(375, 196);  // Ajusta esta posición según sea necesario
        escena->addItem(enemigo->item);  // Añadir de vuelta a la escena
    }

    // Verificar colisiones con los puntos de poder
    std::vector<PuntoDePoder*> puntosDePoderAEliminar;
    for (auto& puntoDePoder : puntosDePoder) {
        if (pacman->collidesWithItem(puntoDePoder)) {
            qDebug() << "Pac-Man colisionó con punto de poder";
            puntosDePoderAEliminar.push_back(puntoDePoder);
            escena->removeItem(puntoDePoder);

            poderActivo = true;  // Activar poder
            for (auto& enemigo : enemigos) {
                enemigo.item->setPixmap(enemigo.texturaAsustado);  // Cambia la textura de los enemigos
            }

            poderTimer->start(11000); // El poder dura 11 segundos
            qDebug() << "Punto de poder activado";
        }
    }

    // Eliminar los puntos de poder consumidos
    for (auto& puntoDePoder : puntosDePoderAEliminar) {
        puntosDePoder.erase(std::remove(puntosDePoder.begin(), puntosDePoder.end(), puntoDePoder), puntosDePoder.end());
        delete puntoDePoder;
    }

    // Verificar colisiones de Pac-Man con el túnel de entrada y salida
    if (pacman->pos().x() >= tunnelEntry.x() - tunnelRadius && pacman->pos().x() <= tunnelEntry.x() + tunnelRadius &&
        pacman->pos().y() >= tunnelEntry.y() - tunnelRadius && pacman->pos().y() <= tunnelEntry.y() + tunnelRadius) {
        pacman->setPos(tunnelExit.x() - tunnelRadius - 1, tunnelExit.y());
        qDebug() << "Pac-Man ha sido teletransportado a la salida del túnel";
    }

    if (pacman->pos().x() >= tunnelExit.x() - tunnelRadius && pacman->pos().x() <= tunnelExit.x() + tunnelRadius &&
        pacman->pos().y() >= tunnelExit.y() - tunnelRadius && pacman->pos().y() <= tunnelExit.y() + tunnelRadius) {
        pacman->setPos(tunnelEntry.x() + tunnelRadius + 1, tunnelEntry.y());
        qDebug() << "Pac-Man ha sido teletransportado a la entrada del túnel";
    }
}




void ventana::moverEnemigos() {
    for (auto& enemigo : enemigos) {
        QPointF newPos = enemigo.item->pos() + QPointF(enemigo.direccion_x, enemigo.direccion_y);

        // Comprobar colisiones con las paredes del mapa
        enemigo.item->setPos(newPos);
        QList<QGraphicsItem*> collidingItems = enemigo.item->collidingItems();
        bool hasCollision = false;

        for (QGraphicsItem* item : collidingItems) {
            if (std::find(paredes.begin(), paredes.end(), item) != paredes.end()) {
                hasCollision = true;
                break;
            }
        }

        // Si hay colisión, revertir el movimiento
        if (hasCollision) {
            enemigo.item->moveBy(-enemigo.direccion_x, -enemigo.direccion_y);
            // Cambiar la dirección aleatoriamente
            int direction = rand() % 4;
            switch (direction) {
            case 0: // Arriba
                enemigo.direccion_x = 0;
                enemigo.direccion_y = -1;
                break;
            case 1: // Abajo
                enemigo.direccion_x = 0;
                enemigo.direccion_y = 1;
                break;
            case 2: // Izquierda
                enemigo.direccion_x = -1;
                enemigo.direccion_y = 0;
                break;
            case 3: // Derecha
                enemigo.direccion_x = 1;
                enemigo.direccion_y = 0;
                break;
            }
        }
    }
}

void ventana::inicializarPosiciones() { //reinicia las posiciones de los enemigos cuando estos chocan con pacman
    pacman->setPos(369, 433);
    move_x = 0;
    move_y= 0;
    // Posición inicial de los enemigos
    enemigos[0].item->setPos(375, 196);
    enemigos[1].item->setPos(375, 196);
    enemigos[2].item->setPos(375, 196);
    enemigos[3].item->setPos(375, 196);
}


void ventana::InicializarParedes(){
    // son las paredes que hacen parte de la escena
    paredes.push_back(new Pared(0, 0, 775, 9, QBrush(Qt::darkCyan)));  //pared superior
    paredes.push_back(new Pared(0, 463, 775, 21, QBrush(Qt::darkCyan))); //pared infereior
    paredes.push_back(new Pared(0, 0, 26, 152, QBrush(Qt::darkCyan))); //pared lat-izqui
    paredes.push_back(new Pared(0, 278, 26, 205, QBrush(Qt::darkCyan)));
    paredes.push_back(new Pared(758, 0, 19, 150, QBrush(Qt::darkCyan)));//pared lat_derecha
    paredes.push_back(new Pared(758, 276, 18, 207, QBrush(Qt::darkCyan)));
    paredes.push_back(new Pared(58, 41, 111, 16, QBrush(Qt::darkCyan))); //1
    paredes.push_back(new Pared(202, 41, 122, 16, QBrush(Qt::darkCyan)));//2
    paredes.push_back(new Pared(367, 0, 42, 57, QBrush(Qt::darkCyan)));//3
    paredes.push_back(new Pared(443, 41, 131, 16, QBrush(Qt::darkCyan)));//4
    paredes.push_back(new Pared(610, 41, 116, 18, QBrush(Qt::darkCyan)));//5
    paredes.push_back(new Pared(58, 89, 110, 16, QBrush(Qt::darkCyan)));//6
    paredes.push_back(new Pared(202, 89, 52, 105, QBrush(Qt::darkCyan)));//7
    paredes.push_back(new Pared(254, 136, 79, 14, QBrush(Qt::darkCyan)));//8
    paredes.push_back(new Pared(289, 89, 204, 16, QBrush(Qt::darkCyan)));//9
    paredes.push_back(new Pared(367, 104, 42, 48, QBrush(Qt::darkCyan)));//10
    paredes.push_back(new Pared(443, 136, 85, 14, QBrush(Qt::darkCyan)));//11
    paredes.push_back(new Pared(527, 89, 47, 105, QBrush(Qt::darkCyan)));//12
    paredes.push_back(new Pared(610, 89, 116, 16, QBrush(Qt::darkCyan)));//13
    paredes.push_back(new Pared(634, 136, 143, 45, QBrush(Qt::darkCyan)));//14
    paredes.push_back(new Pared(610, 136, 24, 44, QBrush(Qt::darkCyan)));//15
    paredes.push_back(new Pared(610, 180, 167, 14, QBrush(Qt::darkCyan)));//16
    paredes.push_back(new Pared(0, 136, 168, 50, QBrush(Qt::darkCyan)));//17
    paredes.push_back(new Pared(145, 150, 23, 44, QBrush(Qt::darkCyan)));//18
    paredes.push_back(new Pared(0, 180, 145, 14, QBrush(Qt::darkCyan)));//19
    paredes.push_back(new Pared(288, 183, 84, 64, QBrush(Qt::darkCyan)));//20
    paredes.push_back(new Pared(373, 228, 33, 19, QBrush(Qt::darkCyan)));//21
    paredes.push_back(new Pared(407, 183,86, 64, QBrush(Qt::darkCyan)));//22
    paredes.push_back(new Pared(527, 227, 47, 67, QBrush(Qt::darkCyan)));//23
    paredes.push_back(new Pared(610, 227, 167, 50, QBrush(Qt::darkCyan)));//24
    paredes.push_back(new Pared(610, 247, 30, 47, QBrush(Qt::darkCyan)));//25
    paredes.push_back(new Pared(636, 276, 141, 18, QBrush(Qt::darkCyan)));//26
    paredes.push_back(new Pared(0, 227, 168, 67, QBrush(Qt::darkCyan)));//27-28-29
    paredes.push_back(new Pared(202, 227, 52, 67, QBrush(Qt::darkCyan)));//30
    paredes.push_back(new Pared(288, 278, 206, 16, QBrush(Qt::darkCyan)));//31
    paredes.push_back(new Pared(366, 294, 44, 46, QBrush(Qt::darkCyan)));//32
    paredes.push_back(new Pared(442, 325, 135, 14, QBrush(Qt::darkCyan)));//33
    paredes.push_back(new Pared(609, 325, 46, 58, QBrush(Qt::darkCyan)));//34
    paredes.push_back(new Pared(655, 325, 69, 13, QBrush(Qt::darkCyan)));//35
    paredes.push_back(new Pared(57, 325,111 , 13, QBrush(Qt::darkCyan)));//36
    paredes.push_back(new Pared(129, 339, 39, 45, QBrush(Qt::darkCyan)));//37
    paredes.push_back(new Pared(202, 325, 132,14 , QBrush(Qt::darkCyan)));//38
    paredes.push_back(new Pared(22, 371, 69, 13, QBrush(Qt::darkCyan)));//39
    paredes.push_back(new Pared(202, 370, 52, 46, QBrush(Qt::darkCyan)));//40
    paredes.push_back(new Pared(300, 371, 194, 13, QBrush(Qt::darkCyan)));//41
    paredes.push_back(new Pared(366, 384, 44, 48, QBrush(Qt::darkCyan)));//42
    paredes.push_back(new Pared(526, 370, 49, 45, QBrush(Qt::darkCyan)));//43
    paredes.push_back(new Pared(689, 370, 69, 13, QBrush(Qt::darkCyan)));//44
    paredes.push_back(new Pared(58, 416, 276, 14, QBrush(Qt::darkCyan)));//45
    paredes.push_back(new Pared(442, 415, 283, 14, QBrush(Qt::darkCyan)));//46
    //las siguientes paredes se encargan que el movimiento sea mas "fluido"
    paredes.push_back(new Pared(26,461,1,1,QBrush(Qt::black)));
    paredes.push_back(new Pared(757,461,1,1,QBrush(Qt::black)));
    paredes.push_back(new Pared(202,295,1,1, QBrush(Qt::black)));
    paredes.push_back(new Pared(201,193,1,1, QBrush(Qt::black)));
    paredes.push_back(new Pared(608,193,1,2, QBrush(Qt::black)));
    paredes.push_back(new Pared(167,57,1,1, QBrush(Qt::black)));

    // Añadir más paredes según sea necesario con sus respectivos colores
    for (auto& pared : paredes) {
        escena->addItem(pared);
    }

}

void ventana::inicializarElipses() { //son los puntos amarillos que se generan por el mapa
    //primer pasillo
    elipses.push_back(new Elipse(40, 20, 10, 10, QBrush(Qt::yellow)));//1
    elipses.push_back(new Elipse(90, 20, 10, 10, QBrush(Qt::yellow)));//2
    elipses.push_back(new Elipse(140, 20, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(180, 20, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(240, 20, 10, 10, QBrush(Qt::yellow)));//5
    elipses.push_back(new Elipse(290, 20, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 20, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(440, 20, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 20, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(540, 20, 10, 10, QBrush(Qt::yellow)));//11
    elipses.push_back(new Elipse(590, 20, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 20, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 20, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 20, 10, 10, QBrush(Qt::yellow)));//15
    //segundo pasillo
    elipses.push_back(new Elipse(40, 70, 10, 10, QBrush(Qt::yellow)));//1
    elipses.push_back(new Elipse(90, 70, 10, 10, QBrush(Qt::yellow)));//2
    elipses.push_back(new Elipse(140, 70, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(180, 70, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(240, 70, 10, 10, QBrush(Qt::yellow)));//5
    elipses.push_back(new Elipse(290, 70, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 70, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(390, 70, 10, 10, QBrush(Qt::yellow)));//8
    elipses.push_back(new Elipse(440, 70, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 70, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(540, 70, 10, 10, QBrush(Qt::yellow)));//11
    elipses.push_back(new Elipse(590, 70, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 70, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 70, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 70, 10, 10, QBrush(Qt::yellow)));//15
    //tercer pasillo
    elipses.push_back(new Elipse(40, 115, 10, 10, QBrush(Qt::yellow))); //1
    elipses.push_back(new Elipse(90, 115, 10, 10, QBrush(Qt::yellow))); //2
    elipses.push_back(new Elipse(140, 115, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(180, 115, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(290, 115, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 115, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(440, 115, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 115, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(590, 115, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 115, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 115, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 115, 10, 10, QBrush(Qt::yellow)));//15
    //cuarto pasillo

    elipses.push_back(new Elipse(180, 160, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(290, 160, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 160, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(390, 160, 10, 10, QBrush(Qt::yellow)));//8
    elipses.push_back(new Elipse(440, 160, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 160, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(590, 160, 10, 10, QBrush(Qt::yellow)));//12
    //quinto pasillo
    elipses.push_back(new Elipse(40, 205, 10, 10, QBrush(Qt::yellow))); //1
    elipses.push_back(new Elipse(90, 205, 10, 10, QBrush(Qt::yellow))); //2
    elipses.push_back(new Elipse(140, 205, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(190, 205, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(240, 205, 10, 10, QBrush(Qt::yellow)));//5
    elipses.push_back(new Elipse(540, 205, 10, 10, QBrush(Qt::yellow)));//11
    elipses.push_back(new Elipse(590, 205, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 205, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 205, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 205, 10, 10, QBrush(Qt::yellow)));//15
    //sexto pasillo

    elipses.push_back(new Elipse(180, 255, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(290, 255, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 255, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(390, 255, 10, 10, QBrush(Qt::yellow)));//8
    elipses.push_back(new Elipse(440, 255, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 255, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(590, 255, 10, 10, QBrush(Qt::yellow)));//12
    //septimo pasillo
    elipses.push_back(new Elipse(40, 305, 10, 10, QBrush(Qt::yellow))); //1
    elipses.push_back(new Elipse(90, 305, 10, 10, QBrush(Qt::yellow))); //2
    elipses.push_back(new Elipse(140, 305, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(180, 305, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(240, 305, 10, 10, QBrush(Qt::yellow)));//5
    elipses.push_back(new Elipse(290, 305, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 305, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(440, 305, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 305, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(540, 305, 10, 10, QBrush(Qt::yellow)));//11
    elipses.push_back(new Elipse(590, 305, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 305, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 305, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 305, 10, 10, QBrush(Qt::yellow)));//15
    //octavo pasillo
    elipses.push_back(new Elipse(40, 350, 10, 10, QBrush(Qt::yellow))); //1
    elipses.push_back(new Elipse(90, 350, 10, 10, QBrush(Qt::yellow))); //2
    elipses.push_back(new Elipse(180, 350, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(240, 350, 10, 10, QBrush(Qt::yellow)));//5
    elipses.push_back(new Elipse(290, 350, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 350, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(390, 350, 10, 10, QBrush(Qt::yellow)));//8
    elipses.push_back(new Elipse(440, 350, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 350, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(540, 350, 10, 10, QBrush(Qt::yellow)));//11

    elipses.push_back(new Elipse(740, 350, 10, 10, QBrush(Qt::yellow)));//15
    //noveno pasillo
    elipses.push_back(new Elipse(40, 390, 10, 10, QBrush(Qt::yellow))); //1
    elipses.push_back(new Elipse(90, 390, 10, 10, QBrush(Qt::yellow))); //2
    elipses.push_back(new Elipse(140, 390, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(180, 390, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(290, 390, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 390, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(440, 390, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 390, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(590, 390, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 390, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 390, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 390, 10, 10, QBrush(Qt::yellow)));//15
    //decimo pasillo
    elipses.push_back(new Elipse(40, 445, 10, 10, QBrush(Qt::yellow))); //1
    elipses.push_back(new Elipse(90, 445, 10, 10, QBrush(Qt::yellow))); //2
    elipses.push_back(new Elipse(140, 445, 10, 10, QBrush(Qt::yellow)));//3
    elipses.push_back(new Elipse(180, 445, 10, 10, QBrush(Qt::yellow)));//4
    elipses.push_back(new Elipse(240, 445, 10, 10, QBrush(Qt::yellow)));//5
    elipses.push_back(new Elipse(290, 445, 10, 10, QBrush(Qt::yellow)));//6
    elipses.push_back(new Elipse(340, 445, 10, 10, QBrush(Qt::yellow)));//7
    elipses.push_back(new Elipse(390, 445, 10, 10, QBrush(Qt::yellow)));//8
    elipses.push_back(new Elipse(440, 445, 10, 10, QBrush(Qt::yellow)));//9
    elipses.push_back(new Elipse(490, 445, 10, 10, QBrush(Qt::yellow)));//10
    elipses.push_back(new Elipse(540, 445, 10, 10, QBrush(Qt::yellow)));//11
    elipses.push_back(new Elipse(590, 445, 10, 10, QBrush(Qt::yellow)));//12
    elipses.push_back(new Elipse(690, 445, 10, 10, QBrush(Qt::yellow)));//13
    elipses.push_back(new Elipse(640, 445, 10, 10, QBrush(Qt::yellow)));//14
    elipses.push_back(new Elipse(740, 445, 10, 10, QBrush(Qt::yellow)));//15
    // Añadir más elipses según sea necesario

    cant_elipses = elipses.size();
    for (Elipse* elipse : elipses) {
        escena->addItem(elipse);
    }
}

void ventana::inicializarPuntosdePoder() {
    // muestra/genera los poderes que se encuentran en la escena
    puntosDePoder.push_back(new PuntoDePoder(585, 390, 20, 20, QBrush(Qt::green)));
    puntosDePoder.push_back(new PuntoDePoder(175, 390, 20, 20, QBrush(Qt::green)));
    puntosDePoder.push_back(new PuntoDePoder(730, 110, 20, 20, QBrush(Qt::green)));
    puntosDePoder.push_back(new PuntoDePoder(35, 110, 20, 20, QBrush(Qt::green)));

    for(PuntoDePoder* PuntoDePoder : puntosDePoder){
        escena->addItem(PuntoDePoder);
    }

}


void ventana::desactivarPoder() {
    // Desactiva el poder especial
    poderActivo = false;

    // Itera sobre todos los enemigos en la lista de enemigos
    for (auto& enemigo : enemigos) {
        // Cambia la textura del enemigo al estado normal
        enemigo.item->setPixmap(enemigo.texturaNormal);
    }
}



void ventana::FindelJuego() {
    // Detiene el temporizador asociado con el personaje
    timerPersonaje->stop();

    // Detiene el temporizador asociado con los enemigos
    timerEnemigos->stop();

    // Muestra un mensaje de información indicando el fin del juego
    // El primer argumento es el widget padre, el segundo es el título de la ventana del mensaje,
    // y el tercero es el texto del mensaje.
    QMessageBox::information(this, "Fin del juego", "Haz perdido, Presione R para reiniciar");
}

void ventana::ganar() {
    timerPersonaje->stop();
    timerEnemigos->stop();
    QMessageBox::information(this, "¡Has ganado!", "¡Felicidades!");
}

