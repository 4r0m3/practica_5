#include "PuntoDePoder.h"

PuntoDePoder::PuntoDePoder(qreal x, qreal y, qreal width, qreal height, QBrush brush)
    : QGraphicsEllipseItem(x, y, width, height)
{
    setBrush(brush);
}

void PuntoDePoder::activarPoder() {
    // Aquí puedes definir lo que sucede cuando se activa el poder
}
