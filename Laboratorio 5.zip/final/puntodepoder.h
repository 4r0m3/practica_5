#ifndef PUNTODEPODePoder
#define PUNTODEPODePoder
#include "QBrush"
#include <QGraphicsEllipseItem>

class PuntoDePoder : public QGraphicsEllipseItem {
public:
    PuntoDePoder(qreal x, qreal y, qreal width, qreal height, QBrush brush);

    // Método para activar el poder
    void activarPoder();
};

#endif // PUNTODEPODePoder
