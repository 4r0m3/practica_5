#include "pared.h"
#include "QPen"

Pared::Pared(qreal x, qreal y, qreal width, qreal height, const QBrush& brush)
{
    setRect(x, y, width, height);
    setBrush(brush);
    setPen(QPen(Qt::NoPen)); //hace que no halla un contorno en la figura
}
