#ifndef VENTANA_H
#define VENTANA_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include <vector>
#include "pared.h"
#include "elipse.h"
#include "puntodepoder.h"
#include "qmessagebox.h"
#define PATH_IMG ":/imagens/Captura.PNG"


QT_BEGIN_NAMESPACE
namespace Ui {
class ventana;
}
QT_END_NAMESPACE

enum TipoMovimiento { SEMIALEATORIO };

struct Enemigo {
    QGraphicsPixmapItem* item;
    int direccion_x;
    int direccion_y;
    TipoMovimiento tipo;
    QPixmap texturaNormal;
    QPixmap texturaAsustado;
};

class ventana : public QMainWindow {
    Q_OBJECT

public:
    ventana(QWidget *parent = nullptr);
    ~ventana();

protected:
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void actualizar();
    void moverEnemigos();
    void desactivarPoder();

private:
    Ui::ventana *ui;
    QGraphicsScene *escena;
    QPixmap *pixmap;
    QGraphicsPixmapItem *pacman;
    QTimer *timerPersonaje;
    QTimer *timerEnemigos;
    QTimer *poderTimer;
    QGraphicsRectItem* punt;
    QGraphicsPixmapItem* vida;
    QGraphicsPixmapItem* vida2;
    QGraphicsPixmapItem* vida3;
    QGraphicsPixmapItem* vida4;
    QGraphicsTextItem *textoPuntaje; // Texto para mostrar el puntaje
    std::vector<Elipse*> elipses;// Elipses que representan los puntos
    std::vector<QGraphicsItem *> paredes;
    std::vector<Enemigo> enemigos;
    std::vector<PuntoDePoder*> puntosDePoder;
    int move_x;
    int move_y;
    int coorX, coorY, ancho, alto;
    int coorX1, coorY1, coorX2, coorY2;
    int life;
    int puntaje; // Variable para manejar el puntaje
    int cant_elipses;
    bool boca_abierta;
    bool poderActivo;


    void inicializarPuntosdePoder();
    void inicailizarEscenario();
    void inicializarPersonje();
    void InicializarParedes();
    void inicializarPosiciones();
    void inicializarEnemigos();
    void inicializarElipses();
    void FindelJuego();
    void ganar();
};

#endif // VENTANA_H
