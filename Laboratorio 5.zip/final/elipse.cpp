#include "elipse.h"
#include "QPen"

Elipse::Elipse(qreal x, qreal y, qreal width, qreal height, const QBrush& brush) {
    setRect(x, y, width, height);
    setBrush(brush);
    setPen(QPen(Qt::NoPen)); // Asegurar que el contorno no sea visible
}
