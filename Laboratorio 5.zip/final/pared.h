#ifndef PARED_H
#define PARED_H

#include <QGraphicsRectItem>
#include <QBrush>

class Pared : public QGraphicsRectItem
{
public:
    Pared(qreal x, qreal y, qreal width, qreal height, const QBrush& brush);
};

#endif // PARED_H

